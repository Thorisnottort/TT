from django.urls import path, include
from .views import index, tour, tours, admin, about, register, profile, roadmap_detail
from django.contrib.auth import views as auth_views


urlpatterns = [
    path('', index, name='index'),
    path('tour/<int:tour_id>', tour, name='tour'),
    path('tours', tours, name='tours'),
    path('client/admin', admin, name='client_admin'),
    path('about', about, name='about'),
    path('register/', register, name='register'),
    path('login/', auth_views.LoginView.as_view(
        template_name='login.html',
        extra_context={'next': "/"}
    ), name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    path('profile/', profile, name='profile'),
    path('roadmaps/<int:pk>/', roadmap_detail, name='roadmap_detail'),
]
