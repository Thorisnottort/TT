from django.contrib.auth.models import User
from django.db import models


# Model of a tour
class Tour(models.Model):
    tour_name = models.CharField(max_length=200)
    tour_description = models.CharField(max_length=200)
    tour_price = models.IntegerField()
    tour_duration = models.IntegerField()
    tour_image = models.URLField()
    next_date = models.DateField(null=True, blank=True)

    def __str__(self):
        return self.tour_name


# Model of a roadmap
class Roadmap(models.Model):
    tour = models.ForeignKey(Tour, on_delete=models.CASCADE)
    roadmap_title = models.CharField(max_length=200)
    roadmap_description = models.CharField(max_length=10000)
    image = models.URLField(null=True, blank=True)

    def __str__(self):
        return self.roadmap_title


# Model of an order
class Order(models.Model):
    tour = models.ForeignKey(Tour, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    order_name = models.CharField(max_length=200)
    order_phone = models.CharField(max_length=200)
    order_successful = models.BooleanField(default=False)

    def __str__(self):
        return self.order_name
